/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package learnhub;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author THINKPAD
 */
public class KelasSiswa extends javax.swing.JFrame {
    private int idKelas;
    private int id;
    private Connection conn;
    String nama;
    /**
     * Creates new form KelasPengajar
     */
    public KelasSiswa(int idKelas,int id,String s) {
        initComponents();
        conn = koneksi.getKoneksi();
        this.idKelas = idKelas;
        this.id = id;
        this.nama = s;
        loadClassData();
        saveOrDisplayData(idKelas, id);
        loadComboTugas();
    }
    private void loadDataToTextArea(int idTugas) {
    try {
        // Query untuk mengambil data berdasarkan ID tugas
        String sql = "SELECT t.judul AS nama_tugas, ts.nama_siswa, ts.status_nilai "
                   + "FROM tugas_siswa ts "
                   + "JOIN tugas t ON ts.id_tugas = t.id "
                   + "WHERE t.id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, idTugas);  // Set ID tugas yang dipilih
        ResultSet rs = ps.executeQuery();

        // Reset TextArea sebelum menampilkan data
        areaNilai.setText("");

        // Variabel untuk menyimpan data yang akan ditampilkan
        StringBuilder data = new StringBuilder();

        // Iterasi melalui hasil query
        while (rs.next()) {
            String namaTugas = rs.getString("nama_tugas");
            String namaSiswa = rs.getString("nama_siswa");
            String nilai = rs.getString("status_nilai");

            // Format data untuk ditampilkan
            data.append("Nama Tugas: ").append(namaTugas).append("\n")
                .append("Nama Siswa: ").append(namaSiswa).append("\n")
                .append("Nilai: ").append(nilai).append("\n")
                .append("-------------------------\n");
        }

        // Menampilkan data di TextArea
        areaNilai.setText(data.toString());

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error Load Data Tugas Siswa: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// Metode untuk memeriksa keberadaan data di database sebelum menyimpannya
private void saveOrDisplayData(int idKelas, int idUser) {
    try {
        // Query untuk mengecek apakah data sudah ada
        String checkQuery = "SELECT COUNT(*) FROM anggota_kelas WHERE id_kelas = ? AND id_user = ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
        checkStmt.setInt(1, idKelas); // Set parameter id_kelas
        checkStmt.setInt(2, idUser); // Set parameter id_user
        ResultSet rs = checkStmt.executeQuery();
        rs.next();
        int count = rs.getInt(1); // Mendapatkan jumlah hasil
        if (count > 0) {
            // Jika data sudah ada, tampilkan pesan
            JOptionPane.showMessageDialog(this, "Data anggota sudah ada di kelas!", "Informasi", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Jika data belum ada, simpan data ke database
            String insertQuery = "INSERT INTO anggota_kelas (id_kelas, id_user) VALUES (?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setInt(1, idKelas);
            insertStmt.setInt(2, idUser);
            int rowsInserted = insertStmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Data anggota berhasil disimpan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menyimpan data anggota!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        }
        // Setelah menyimpan atau memeriksa data, muat ulang daftar anggota
        loadDataMember(idKelas);
    } catch (SQLException e) {
        // Tangani kesalahan SQL
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat memproses data: " + e.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}
    private void loadClassData() {
        try {
            String query = "SELECT * FROM classes WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, idKelas); // Set ID kelas pada prepared statement
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Ambil data dari database berdasarkan ID kelas
                String namaKelas = rs.getString("nama_kelas");
                String mataPelajaran = rs.getString("mata_pelajaran");
                // Set label dengan data yang diterima
                nkLabel.setText("Nama Kelas: " + namaKelas);
                mpLabel.setText("Mata Pelajaran: " + mataPelajaran);
            }else {
                JOptionPane.showMessageDialog(this, "Data kelas tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal memuat data kelas.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
private void loadDataMember(int idKelas) {
    try {
        // Bersihkan area sebelum mengisi data baru
        pengajarArea.setText("");
        siswaArea.setText("");
        // Query tunggal untuk pengajar dan siswa
        String query = """
            SELECT u.username, u.role FROM anggota_kelas ak
            JOIN users u ON ak.id_user = u.id
            WHERE ak.id_kelas = ?
        """;

        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, idKelas);

        ResultSet rs = stmt.executeQuery();

        int pengajarIndex = 1;
        int siswaIndex = 1;

        while (rs.next()) {
            String username = rs.getString("username");
            String role = rs.getString("role");

            if ("Pengajar".equalsIgnoreCase(role)) {
                pengajarArea.append(pengajarIndex++ + ". " + username + "\n");
            } else if ("Siswa".equalsIgnoreCase(role)) {
                siswaArea.append(siswaIndex++ + ". " + username + "\n");
            }
        }
    } catch (SQLException e) {
        // Tampilkan pesan kesalahan spesifik
        JOptionPane.showMessageDialog(this, "Gagal memuat data anggota kelas: " + e.getMessage(),
                "Kesalahan", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace(); // Untuk debugging
    }
}
    private void loadComboTugas() {
    try {
        // Query untuk mengambil semua tugas dari database
        String sql = "SELECT id, judul FROM tugas";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        // Mengisi combo box dengan tugas yang ada
        comboTugas.removeAllItems();  // Kosongkan combo box terlebih dahulu
        comboTugas.addItem("Pilih Tugas");  // Menambahkan pilihan default
        while (rs.next()) {
            // Menambahkan item ke combo box dengan format "ID - Judul"
            int idTugas = rs.getInt("id");
            String judulTugas = rs.getString("judul");
            comboTugas.addItem(idTugas + " - " + judulTugas);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error Load Combo Tugas: " + e.getMessage());
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        nkLabel = new javax.swing.JLabel();
        mpLabel = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        panelMateri = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        panelTugas = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        pengajarArea = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        siswaArea = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        areaNilai = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        comboTugas = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(101, 146, 135));
        jPanel1.setLayout(null);

        jTabbedPane1.setBackground(new java.awt.Color(177, 194, 158));

        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(177, 194, 158));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel5.add(nkLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(199, 10, 150, 20));
        jPanel5.add(mpLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(458, 20, 160, 30));

        jPanel2.add(jPanel5, java.awt.BorderLayout.PAGE_START);

        jPanel6.setBackground(new java.awt.Color(177, 194, 158));

        panelMateri.setBackground(new java.awt.Color(255, 230, 169));
        panelMateri.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateriMouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/learnhub/bookshelf_icon-icons.com_54414.png"))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Materi");

        javax.swing.GroupLayout panelMateriLayout = new javax.swing.GroupLayout(panelMateri);
        panelMateri.setLayout(panelMateriLayout);
        panelMateriLayout.setHorizontalGroup(
            panelMateriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateriLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        panelMateriLayout.setVerticalGroup(
            panelMateriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateriLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelMateriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(panelMateriLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel6)))
                .addGap(16, 16, 16))
        );

        panelTugas.setBackground(new java.awt.Color(255, 230, 169));
        panelTugas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelTugasMouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/learnhub/list_tasks_questionnaire_icon_179856.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Tugas");

        javax.swing.GroupLayout panelTugasLayout = new javax.swing.GroupLayout(panelTugas);
        panelTugas.setLayout(panelTugasLayout);
        panelTugasLayout.setHorizontalGroup(
            panelTugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTugasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        panelTugasLayout.setVerticalGroup(
            panelTugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTugasLayout.createSequentialGroup()
                .addGroup(panelTugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTugasLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel7))
                    .addGroup(panelTugasLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel8)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(16, 16, 16))
        );

        jButton1.setBackground(new java.awt.Color(101, 146, 135));
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(119, 119, 119)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(panelTugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(panelMateri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(257, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(panelMateri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(panelTugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(122, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel6, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Forum", jPanel2);

        jPanel3.setBackground(new java.awt.Color(177, 194, 158));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("Pengajar");

        pengajarArea.setColumns(20);
        pengajarArea.setRows(5);
        jScrollPane2.setViewportView(pengajarArea);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Siswa");

        siswaArea.setColumns(20);
        siswaArea.setRows(5);
        jScrollPane1.setViewportView(siswaArea);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 351, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap(314, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(94, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Member", jPanel3);

        jPanel4.setBackground(new java.awt.Color(177, 194, 158));

        areaNilai.setColumns(20);
        areaNilai.setRows(5);
        jScrollPane3.setViewportView(areaNilai);

        jLabel11.setText("Pilih Tugas");

        comboTugas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Tugasnya" }));
        comboTugas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboTugasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(157, 157, 157)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(83, 83, 83)
                        .addComponent(comboTugas, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3))
                .addContainerGap(191, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(comboTugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Nilai", jPanel4);

        jPanel1.add(jTabbedPane1);
        jTabbedPane1.setBounds(10, 10, 730, 460);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 749, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 496, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void comboTugasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboTugasActionPerformed
        // TODO add your handling code here:
  // Pastikan tugas dipilih
    String selectedItem = (String) comboTugas.getSelectedItem();
    if (selectedItem != null && !selectedItem.equals("Pilih Tugas")) {
        // Ambil ID tugas dari pilihan ComboBox
        String[] parts = selectedItem.split(" - ");
        int idTugas = Integer.parseInt(parts[0]);

        // Load data ke TextArea
        loadDataToTextArea(idTugas);
    }
    }//GEN-LAST:event_comboTugasActionPerformed

    private void panelMateriMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateriMouseClicked
        // TODO add your handling code here:
        MateriSiswa frameMateri = new MateriSiswa();
        frameMateri.setVisible(true);
    }//GEN-LAST:event_panelMateriMouseClicked

    private void panelTugasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelTugasMouseClicked
        // TODO add your handling code here:
        TugasSiswa frameTugas = new TugasSiswa(nama,id);
        frameTugas.setVisible(true);
    }//GEN-LAST:event_panelTugasMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        HomepageSiswa homepage2 = new HomepageSiswa(id, nama); // Kirim username yang valid
        homepage2.setVisible(true); // Tampilkan homepage siswa
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KelasSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KelasSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KelasSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KelasSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new KelasSiswa(0,0,"").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaNilai;
    private javax.swing.JComboBox<String> comboTugas;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel mpLabel;
    private javax.swing.JLabel nkLabel;
    private javax.swing.JPanel panelMateri;
    private javax.swing.JPanel panelTugas;
    private javax.swing.JTextArea pengajarArea;
    private javax.swing.JTextArea siswaArea;
    // End of variables declaration//GEN-END:variables
}
