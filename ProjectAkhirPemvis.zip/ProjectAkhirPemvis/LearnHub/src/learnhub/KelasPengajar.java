/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package learnhub;
import java.sql.ResultSet;
import java.sql.*;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.swing.JOptionPane;
import java.sql.Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
/**
 *
 * @author THINKPAD
 */
public class KelasPengajar extends javax.swing.JFrame {
    private int idKelas;
    private int id;
    private Connection conn;
     private String user;
    /**
     * Creates new form KelasPengajar
     */
    public KelasPengajar(int idKelas,int id) {
        initComponents();
        conn = koneksi.getKoneksi();
        this.idKelas = idKelas;
        this.user =user;
        loadClassData();
        saveOrDisplayData(idKelas, id);
        loadComboTugas();
    }
private void loadTblTugasById(int idTugas) {
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("No");
    model.addColumn("Nama Tugas");
    model.addColumn("Nama Siswa");
    model.addColumn("Nama File");
    model.addColumn("Tipe File");
    model.addColumn("Waktu Pengumpulan");
    model.addColumn("Status Pengumpulan");
    model.addColumn("Status Nilai");
     model.addColumn("ID");
    try {
        // Query untuk mengambil data berdasar ID tugas
        String sql = "SELECT ts.id, t.judul, ts.nama_siswa, ts.nama_file, ts.tipe_file, ts.waktu_pengumpulan, ts.status_pengumpulan, ts.status_nilai "
                   + "FROM tugas_siswa ts "
                   + "JOIN tugas t ON ts.id_tugas = t.id "
                   + "WHERE t.id = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, idTugas);
        ResultSet rs = ps.executeQuery();
        int nomor = 1;  
        while (rs.next()) {
            java.sql.Timestamp waktuPengumpulan = rs.getTimestamp("waktu_pengumpulan");
            String formattedWaktuPengumpulan = (waktuPengumpulan != null) ?
                new SimpleDateFormat("yyyy-MM-dd HH:mm").format(waktuPengumpulan) : "";
            model.addRow(new Object[]{
                nomor++,
                rs.getString("judul"),
                rs.getString("nama_siswa"),
                rs.getString("nama_file"),
                rs.getString("tipe_file"),
                formattedWaktuPengumpulan,
                rs.getString("status_pengumpulan"),
                rs.getString("status_nilai"),
                 rs.getInt("id"),
            });
        }
        tabelTgsSiswa.setModel(model);
        // Menyembunyikan kolom Tipe File
        tabelTgsSiswa.getColumnModel().getColumn(4).setMinWidth(0);
        tabelTgsSiswa.getColumnModel().getColumn(4).setMaxWidth(0);
        tabelTgsSiswa.getColumnModel().getColumn(4).setWidth(0);
        // Menyembunyikan kolom ID
        tabelTgsSiswa.getColumnModel().getColumn(8).setMinWidth(0);
        tabelTgsSiswa.getColumnModel().getColumn(8).setMaxWidth(0);
        tabelTgsSiswa.getColumnModel().getColumn(8).setWidth(0);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error Load Data Tugas Siswa: " + e.getMessage());
    }
}
// Metod untuk memeriksa keberadaan data di database sebelum menyimpannya
private void saveOrDisplayData(int idKelas, int idUser) {
    try {
        // Query untuk cek apakah data sudah ada
        String checkQuery = "SELECT COUNT(*) FROM anggota_kelas WHERE id_kelas = ? AND id_user = ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
        checkStmt.setInt(1, idKelas);
        checkStmt.setInt(2, idUser); 
        ResultSet rs = checkStmt.executeQuery();
        rs.next();
        int count = rs.getInt(1); 
        if (count > 0) {
            JOptionPane.showMessageDialog(this, "Data anggota sudah ada di kelas!", "Informasi", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Jika data belum ada, simpan data ke database
            String insertQuery = "INSERT INTO anggota_kelas (id_kelas, id_user) VALUES (?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setInt(1, idKelas);
            insertStmt.setInt(2, idUser);
            int rowsInserted = insertStmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Data anggota berhasil disimpan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menyimpan data anggota!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        }
        loadDataMember(idKelas);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat memproses data: " + e.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}
private void loadClassData() {
        try {
            String query = "SELECT * FROM classes WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, idKelas);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Ambil data dari database berdasar ID kelas
                String namaKelas = rs.getString("nama_kelas");
                String mataPelajaran = rs.getString("mata_pelajaran");
                // Set label dengan data yang diterima
                nkLabel.setText("Nama Kelas: " + namaKelas);
                mpLabel.setText("Mata Pelajaran: " + mataPelajaran);
            }else {
                JOptionPane.showMessageDialog(this, "Data kelas tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal memuat data kelas.", "Error", JOptionPane.ERROR_MESSAGE);
        }
}
private void loadDataMember(int idKelas) {
    try {
        pengajarArea.setText("");
        siswaArea.setText("");
        // Query untuk pengajar dan siswa
        String query = """
            SELECT u.username, u.role FROM anggota_kelas ak
            JOIN users u ON ak.id_user = u.id
            WHERE ak.id_kelas = ?
        """;
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, idKelas);
        ResultSet rs = stmt.executeQuery();
        int pengajarIndex = 1;
        int siswaIndex = 1;
        while (rs.next()) {
            String username = rs.getString("username");
            String role = rs.getString("role");
            if ("Pengajar".equalsIgnoreCase(role)) {
                pengajarArea.append(pengajarIndex++ + ". " + username + "\n");
            } else if ("Siswa".equalsIgnoreCase(role)) {
                siswaArea.append(siswaIndex++ + ". " + username + "\n");
            }
        }
    } catch (SQLException e) {
        // Tampil pesan kesalahan
        JOptionPane.showMessageDialog(this, "Gagal memuat data anggota kelas: " + e.getMessage(),
                "Kesalahan", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}
private void loadComboTugas() {
    try {
        // Query untuk mengambil semua tugas dari database
        String sql = "SELECT id, judul FROM tugas";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        // Mengisi combo box dengan tugas yang ada
        comboTugas.removeAllItems();  
        comboTugas.addItem("Pilih Tugas");  
        while (rs.next()) {
            // Menambahk item ke combo box dengan format "ID - Judul"
            int idTugas = rs.getInt("id");
            String judulTugas = rs.getString("judul");
            comboTugas.addItem(idTugas + " - " + judulTugas);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error Load Combo Tugas: " + e.getMessage());
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        nkLabel = new javax.swing.JLabel();
        mpLabel = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        panelMateri = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        panelTugas = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        btnAbsen = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        pengajarArea = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        siswaArea = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tgsSiswaArea = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabelTgsSiswa = new javax.swing.JTable();
        btnNilai = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        comboTugas = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(101, 146, 135));
        jPanel1.setLayout(null);

        jTabbedPane1.setBackground(new java.awt.Color(177, 194, 158));

        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(177, 194, 158));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel5.add(nkLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(199, 10, 150, 20));
        jPanel5.add(mpLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(458, 20, 160, 30));

        jPanel2.add(jPanel5, java.awt.BorderLayout.PAGE_START);

        jPanel6.setBackground(new java.awt.Color(177, 194, 158));

        panelMateri.setBackground(new java.awt.Color(255, 230, 169));
        panelMateri.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateriMouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/learnhub/bookshelf_icon-icons.com_54414.png"))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("Materi");

        javax.swing.GroupLayout panelMateriLayout = new javax.swing.GroupLayout(panelMateri);
        panelMateri.setLayout(panelMateriLayout);
        panelMateriLayout.setHorizontalGroup(
            panelMateriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateriLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(209, Short.MAX_VALUE))
        );
        panelMateriLayout.setVerticalGroup(
            panelMateriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateriLayout.createSequentialGroup()
                .addGroup(panelMateriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMateriLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel6))
                    .addGroup(panelMateriLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5)))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        panelTugas.setBackground(new java.awt.Color(255, 230, 169));
        panelTugas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelTugasMouseClicked(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/learnhub/list_tasks_questionnaire_icon_179856.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("Tugas");

        javax.swing.GroupLayout panelTugasLayout = new javax.swing.GroupLayout(panelTugas);
        panelTugas.setLayout(panelTugasLayout);
        panelTugasLayout.setHorizontalGroup(
            panelTugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTugasLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(210, Short.MAX_VALUE))
        );
        panelTugasLayout.setVerticalGroup(
            panelTugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTugasLayout.createSequentialGroup()
                .addGroup(panelTugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTugasLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel8))
                    .addGroup(panelTugasLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7)))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jButton1.setBackground(new java.awt.Color(255, 230, 169));
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnAbsen.setBackground(new java.awt.Color(255, 230, 169));
        btnAbsen.setText("Absensi");
        btnAbsen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbsenActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(119, 119, 119)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(btnAbsen)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1))
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(panelTugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(panelMateri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(257, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(panelMateri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(panelTugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(btnAbsen))
                .addContainerGap(140, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel6, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("Forum", jPanel2);

        jPanel3.setBackground(new java.awt.Color(177, 194, 158));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("Pengajar");

        pengajarArea.setColumns(20);
        pengajarArea.setRows(5);
        jScrollPane2.setViewportView(pengajarArea);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Siswa");

        siswaArea.setColumns(20);
        siswaArea.setRows(5);
        jScrollPane1.setViewportView(siswaArea);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 351, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap(314, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(94, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Member", jPanel3);

        jPanel4.setBackground(new java.awt.Color(177, 194, 158));

        jLabel9.setText("Load Data Tugas");

        tgsSiswaArea.setColumns(20);
        tgsSiswaArea.setRows(5);
        jScrollPane3.setViewportView(tgsSiswaArea);

        tabelTgsSiswa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "id siswa", "nama siswa", "file tugas", "status nilai"
            }
        ));
        tabelTgsSiswa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelTgsSiswaMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tabelTgsSiswa);

        btnNilai.setBackground(new java.awt.Color(101, 146, 135));
        btnNilai.setText("Nilai");
        btnNilai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNilaiActionPerformed(evt);
            }
        });

        jLabel10.setText("Tabel Tugas");

        jLabel11.setText("Pilih Tugas");

        comboTugas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Tugasnya" }));
        comboTugas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboTugasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnNilai)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(38, 38, 38)
                        .addComponent(comboTugas, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(25, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(130, 130, 130)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(160, 160, 160))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(comboTugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnNilai)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Nilai", jPanel4);

        jPanel1.add(jTabbedPane1);
        jTabbedPane1.setBounds(10, 10, 730, 460);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 749, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 496, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void comboTugasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboTugasActionPerformed
        // TODO add your handling code here:
        String selectedItem = (String) comboTugas.getSelectedItem();
        // Validasi jika belum memilih tugas
        if (selectedItem == null || selectedItem.equals("Pilih Tugas")) {
            return; 
        }
        // Ekstrak ID tugas dari format "ID - Judul"
        int idTugas = Integer.parseInt(selectedItem.split(" - ")[0].trim());
        // Panggil metod memuat data 
        loadTblTugasById(idTugas);
        // Menutup dropdown ComboBox 
        comboTugas.hidePopup();
    }//GEN-LAST:event_comboTugasActionPerformed

    private void panelMateriMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateriMouseClicked
        // TODO add your handling code here:
        MateriPengajar frameMateri = new MateriPengajar();
        frameMateri.setVisible(true);
    }//GEN-LAST:event_panelMateriMouseClicked

    private void panelTugasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelTugasMouseClicked
        // TODO add your handling code here:
        TugasPengajar frameTugas = new TugasPengajar();
        frameTugas.setVisible(true);
    }//GEN-LAST:event_panelTugasMouseClicked

    private void btnNilaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNilaiActionPerformed
        // TODO add your handling code here:                                        
        // TODO add your handling code here:
         // Mendapatkan baris yang dipilih di tabel
    int row = tabelTgsSiswa.getSelectedRow();
    
    // Pastikan ada baris yang dipilih
    if (row != -1) {
        // Ambil ID tugas_siswa dari kolom ke-9 (indeks 8)
        Object idObject = tabelTgsSiswa.getValueAt(row, 8); 
        if (idObject == null) {
            JOptionPane.showMessageDialog(this, "ID tugas tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int idTugasSiswa = Integer.parseInt(idObject.toString());

        // Tampilkan dialog input untuk nilai
        String inputNilai = JOptionPane.showInputDialog(this, "Masukkan Nilai untuk Tugas:", "Input Nilai", JOptionPane.PLAIN_MESSAGE);
        
        // Periksa apakah inputNilai tidak null dan tidak kosong
        if (inputNilai != null && !inputNilai.trim().isEmpty()) {
            // Perbarui nilai di tabel tugas_siswa
            String sql = "UPDATE tugas_siswa SET status_nilai = ? WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, inputNilai);  // Menyimpan nilai input sebagai status_nilai
                ps.setInt(2, idTugasSiswa);   // Menentukan ID tugas_siswa yang akan diupdate
                
                int affectedRows = ps.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Nilai berhasil diperbarui.", "Berhasil", JOptionPane.INFORMATION_MESSAGE);
                    tgsSiswaArea.setText("");
                    // Optionally, update the table model if needed to reflect the change
                    // This could be done by calling a method that reloads the data, like loadTblTugasById(idTugas)
                } else {
                    JOptionPane.showMessageDialog(this, "Gagal memperbarui nilai. ID tugas tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error saat menyimpan nilai: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Nilai tidak valid. Inputkan nilai yang benar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Pilih tugas siswa terlebih dahulu.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnNilaiActionPerformed

    private void tabelTgsSiswaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelTgsSiswaMouseClicked
        // TODO add your handling code here:
   // Mendapatkan baris yang dipilih
    int row = tabelTgsSiswa.getSelectedRow();
    if (row != -1) {
        // Pastikan bahwa tabel memiliki cukup kolom
        int columnCount = tabelTgsSiswa.getColumnCount();
        if (columnCount > 8) { // Pastikan kolom ke-9 (indeks 8) ada
            Object idObject = tabelTgsSiswa.getValueAt(row, 8);  // Mengambil ID tugas_siswa dari kolom ke-9 (indeks 8)
            if (idObject == null) {
                JOptionPane.showMessageDialog(this, "ID tugas tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
                return; 
            }
            int idTugasSiswa = Integer.parseInt(idObject.toString());

            // Cek jika nilai data lainnya (seperti nama tugas, nama siswa, nama file) null
            String namaTugas = (tabelTgsSiswa.getValueAt(row, 1) != null) ? tabelTgsSiswa.getValueAt(row, 1).toString() : "";
            String namaSiswa = (tabelTgsSiswa.getValueAt(row, 2) != null) ? tabelTgsSiswa.getValueAt(row, 2).toString() : "";
            String namaFile = (tabelTgsSiswa.getValueAt(row, 3) != null) ? tabelTgsSiswa.getValueAt(row, 3).toString() : "";
            String tipeFile = (tabelTgsSiswa.getValueAt(row, 4) != null) ? tabelTgsSiswa.getValueAt(row, 4).toString() : "";
            String statusPengumpulan = (tabelTgsSiswa.getValueAt(row, 6) != null) ? tabelTgsSiswa.getValueAt(row, 6).toString() : "";
            String statusNilai = (tabelTgsSiswa.getValueAt(row, 7) != null) ? tabelTgsSiswa.getValueAt(row, 7).toString() : "";

            // Menampilkan data di TextArea atau TextField
            String tugasDetails = "Nama Tugas: " + namaTugas + "\n" +
                                  "Nama Siswa: " + namaSiswa + "\n" +
                                  "Nama File: " + namaFile + "\n" +
                                  "Tipe File: " + tipeFile + "\n" +
                                  "Status Pengumpulan: " + statusPengumpulan + "\n" +
                                  "Status Nilai: " + statusNilai;

            tgsSiswaArea.setText(tugasDetails); // Menampilkan detail tugas di TextArea

            // Mengambil data lampiran (file) berdasarkan ID tugas_siswa
            String sql = "SELECT ts.nama_file, ts.tipe_file, ts.lampiran FROM tugas_siswa ts WHERE ts.id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idTugasSiswa);  // Set ID tugas_siswa
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String namaFileLampiran = rs.getString("nama_file");
                        String tipeFileLampiran = rs.getString("tipe_file");
                        Blob blob = rs.getBlob("lampiran");

                        if (blob != null) {
                            // Menyimpan BLOB ke file sementara
                            InputStream inputStream = blob.getBinaryStream();
                            File tempFile = File.createTempFile("lampiran_", "." + tipeFileLampiran);
                            try (FileOutputStream outputStream = new FileOutputStream(tempFile)) {
                                byte[] buffer = new byte[1024];
                                int bytesRead;
                                while ((bytesRead = inputStream.read(buffer)) != -1) {
                                    outputStream.write(buffer, 0, bytesRead);
                                }
                            }
                            if (tempFile.exists() && Desktop.isDesktopSupported()) {
                                Desktop.getDesktop().open(tempFile);  // Membuka file yang di-upload
                            } else {
                                JOptionPane.showMessageDialog(this, "Gagal membuka file lampiran.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(this, "Lampiran tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Tugas dengan ID " + idTugasSiswa + " tidak ditemukan di database.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException | IOException e) {
                    JOptionPane.showMessageDialog(this, "Gagal mengambil atau membuka lampiran.", "Error", JOptionPane.ERROR_MESSAGE);
                    e.printStackTrace();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Gagal mengakses database.", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Kolom tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_tabelTgsSiswaMouseClicked

    private void btnAbsenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbsenActionPerformed
        // TODO add your handling code here:
        absensiPengajar absen = new absensiPengajar(); // Kirim username yang valid
        absen.setVisible(true); // Tampilkan homepage siswa
    }//GEN-LAST:event_btnAbsenActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        HomepagePengajar homepage1 = new HomepagePengajar(user); // Kirim username yang valid
        homepage1.setVisible(true); // Tampilkan homepage siswa
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KelasPengajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KelasPengajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KelasPengajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KelasPengajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new KelasPengajar(0,0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbsen;
    private javax.swing.JButton btnNilai;
    private javax.swing.JComboBox<String> comboTugas;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel mpLabel;
    private javax.swing.JLabel nkLabel;
    private javax.swing.JPanel panelMateri;
    private javax.swing.JPanel panelTugas;
    private javax.swing.JTextArea pengajarArea;
    private javax.swing.JTextArea siswaArea;
    private javax.swing.JTable tabelTgsSiswa;
    private javax.swing.JTextArea tgsSiswaArea;
    // End of variables declaration//GEN-END:variables
}
