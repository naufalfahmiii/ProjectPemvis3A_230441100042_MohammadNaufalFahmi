/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package learnhub;

/**
 *
 * @author THINKPAD
 */
public class NewClass {
    public class Session {
    public static String currentUsername; // Variabel global untuk username pengguna
}
    
}
