/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package learnhub;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import java.sql.SQLException;
import java.io.File;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
/**
 *
 * @author THINKPAD
 */
public class HomepageSiswa extends javax.swing.JFrame {
    private Connection conn;
    private int id;
    private String user;
//    private String kodeKelas;
//    private String kodeKelasInput;
//    private String kodeKelasFilter;
    String fileTypeVar;
    private byte[] iconBytes;
//    private int siswaId;
    int id_pertemuan;
    /**
     * Creates new form Homepage
     */
    public HomepageSiswa(int id,String user) {
        initComponents();
        conn = koneksi.getKoneksi();
        this.user =user;
        this.id = id;
        loadClasses();
        loadComboBoxData();
    }
private void loadClasses() {
    berandaPanel.removeAll(); 
    JPanel rowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10)); 
    rowPanel.setBackground(new Color(177, 194, 158));
    berandaPanel.add(rowPanel); 
    int count = 0;
    try {
        // Dapat ID kelas yang berhubungan dengan user 
        String queryy = "SELECT id_kelas FROM anggota_kelas WHERE id_user = (SELECT id FROM users WHERE username = ?)";
        PreparedStatement stm = conn.prepareStatement(queryy);
        stm.setString(1, user); 
        ResultSet rss = stm.executeQuery();
        // cek apakah ada ID kelas yang ditemukan
        while (rss.next()) {
            int idKelas = rss.getInt("id_kelas");
            // Dapat informasi kelas berdasarkan id_kelas
            String query = "SELECT * FROM classes WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, idKelas);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String namaKelas = rs.getString("nama_kelas");
                String waktu = rs.getString("waktu");
                String kodeKelas = rs.getString("kode_kelas");
                JPanel panel = new JPanel(new GridLayout(3, 1));
                panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1)); 
                panel.setBackground(new Color(255, 230, 169)); 
                panel.setPreferredSize(new Dimension(200, 150));
                JLabel namaKelasLabel = new JLabel("Nama Kelas: " + namaKelas);
                panel.add(namaKelasLabel);
                panel.add(new JLabel("Waktu: " + waktu));
                panel.add(new JLabel("Kode Kelas: " + kodeKelas));
                panel.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        String kelasName = namaKelas;
                        try {
                            // dapatkan ID kelas dan siswa
                            String queryKelas = "SELECT id FROM classes WHERE nama_kelas = ?";
                            String querySiswa = "SELECT id FROM users WHERE username = ?";
                            PreparedStatement stmtKelas = conn.prepareStatement(queryKelas);
                            PreparedStatement stmtSiswa = conn.prepareStatement(querySiswa);
                            stmtKelas.setString(1, kelasName);
                            stmtSiswa.setString(1, user); 
                            ResultSet rsKelas = stmtKelas.executeQuery();
                            ResultSet rsSiswa = stmtSiswa.executeQuery();
                            if (rsKelas.next() && rsSiswa.next()) {
                                int idKelas = rsKelas.getInt("id");
                                int idSiswa = rsSiswa.getInt("id");
                                // Buka frame KelasSiswa untuk siswa
                                new KelasSiswa(idKelas, idSiswa,user).setVisible(true);
                            } else {
                                JOptionPane.showMessageDialog(null, "Kelas atau pengguna tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(null, "Gagal memuat data kelas.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                });
                rowPanel.add(panel);
                count++;
                // sudah mencapai 3 panel, buat baris baru
                if (count % 3 == 0) {
                    rowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10)); 
                    rowPanel.setBackground(new Color(177, 194, 158));
                    berandaPanel.add(rowPanel);
                }
            }
        }
        // Tambah baris terakhir jika tidak kosong
        if (count % 3 != 0) {
            berandaPanel.add(rowPanel);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Gagal memuat data kelas dari database.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    berandaPanel.revalidate();
    berandaPanel.repaint();
}
private void loadComboBoxData() {
        try {
            comboPilih.removeAllItems();
            comboPilih.addItem("Silahkan Pilih");
            // Query mendapat data nama_pertemuan dari tabel absensi
            String sql = "SELECT nama_pertemuan FROM absensi";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            // Tambah data nama_pertemuan ke ComboBox
            while (rs.next()) {
                String namaPertemuan = rs.getString("nama_pertemuan");
                comboPilih.addItem(namaPertemuan);  // Hanya tambah nama pertemuan
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error load data absensi: " + e.getMessage());
        }
}
private String getFileExtension(File file) {
        String name = file.getName();
        int lastIndex = name.lastIndexOf('.');
        if (lastIndex > 0 && lastIndex < name.length() - 1) {
            return name.substring(lastIndex + 1).toLowerCase();
        }
        return "unknown";
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        homePanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        berandaPanel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        tfKode = new javax.swing.JTextField();
        btnJoin = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        comboPilih = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        labelAbsensi = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(101, 146, 135));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/learnhub/chalkboard_icon-icons.com_54408.png"))); // NOI18N

        jButton1.setBackground(new java.awt.Color(177, 194, 158));
        jButton1.setText("Logout");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTabbedPane1.setBackground(new java.awt.Color(177, 194, 158));
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        berandaPanel.setBackground(new java.awt.Color(177, 194, 158));
        berandaPanel.setLayout(new javax.swing.BoxLayout(berandaPanel, javax.swing.BoxLayout.Y_AXIS));
        jScrollPane1.setViewportView(berandaPanel);

        javax.swing.GroupLayout homePanelLayout = new javax.swing.GroupLayout(homePanel);
        homePanel.setLayout(homePanelLayout);
        homePanelLayout.setHorizontalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        homePanelLayout.setVerticalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jTabbedPane1.addTab("Beranda", homePanel);

        jPanel3.setBackground(new java.awt.Color(177, 194, 158));
        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel5.setBackground(new java.awt.Color(255, 230, 169));

        jLabel11.setText("Masukkan Kode Kelas");

        btnJoin.setBackground(new java.awt.Color(177, 194, 158));
        btnJoin.setText("Join");
        btnJoin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJoinActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnJoin)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel11)
                        .addComponent(tfKode, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfKode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(btnJoin)
                .addContainerGap(164, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(57, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Join Kelas", jPanel3);

        jPanel2.setBackground(new java.awt.Color(177, 194, 158));

        jLabel2.setText("Pilih Pertemuan");

        comboPilih.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Silahkan Pilih" }));

        jLabel3.setText("Bukti");

        jButton2.setBackground(new java.awt.Color(101, 146, 135));
        jButton2.setText("Upload");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(101, 146, 135));
        jButton3.setText("Kirim");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(142, 142, 142)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton3)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jButton2)
                                .addGap(18, 18, 18)
                                .addComponent(labelAbsensi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(comboPilih, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(83, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(comboPilih, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(jButton2))
                    .addComponent(labelAbsensi, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(jButton3)
                .addContainerGap(177, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Absensi", jPanel2);

        jLabel4.setFont(new java.awt.Font("Square721 BT", 1, 36)); // NOI18N
        jLabel4.setText("LearnHub");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 656, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)))
                .addGap(22, 22, 22))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                .addGap(28, 28, 28)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(52, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnJoinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJoinActionPerformed
        // TODO add your handling code here:
        String kodeKelas = tfKode.getText().trim();
        if (kodeKelas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Harap masukkan kode kelas!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            // Ambil id siswa berdasar username yang sedang login
            String querySiswa = "SELECT id FROM users WHERE username = ?";
            int idSiswa = -1;
            try (PreparedStatement psSiswa = conn.prepareStatement(querySiswa)) {
                psSiswa.setString(1, user);
                ResultSet rs = psSiswa.executeQuery();
                if (rs.next()) {
                    idSiswa = rs.getInt("id");
                } else {
                    JOptionPane.showMessageDialog(this, "User tidak ditemukan!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            // cek kode kelas ada di tabel classes
            String queryKelas = "SELECT kode_kelas FROM classes WHERE kode_kelas = ?";
            try (PreparedStatement psKelas = conn.prepareStatement(queryKelas)) {
                psKelas.setString(1, kodeKelas);
                ResultSet rs = psKelas.executeQuery();
                if (!rs.next()) {
                    JOptionPane.showMessageDialog(this, "Kode kelas tidak ditemukan!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            // Simpan data ke tabel kelas_siswa
            String queryInsert = "INSERT INTO kelas_siswa (id_siswa, kode_kelas) VALUES (?, ?)";
            try (PreparedStatement psInsert = conn.prepareStatement(queryInsert)) {
                psInsert.setInt(1, idSiswa);
                psInsert.setString(2, kodeKelas);
                int rows = psInsert.executeUpdate();
                if (rows > 0) {
                    JOptionPane.showMessageDialog(this, "Berhasil bergabung dengan kelas!");
                    loadClasses();
                } else {
                    JOptionPane.showMessageDialog(this, "Gagal bergabung dengan kelas!", "Kesalahan", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
        tfKode.setText("");
    }//GEN-LAST:event_btnJoinActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        JFileChooser chooser = new JFileChooser();
        int result = chooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            String path = file.getAbsolutePath();
            String nama = file.getName();
            labelAbsensi.setText(nama);
            try {
                // Baca file sebagai byte array
                byte[] fileBytes = java.nio.file.Files.readAllBytes(file.toPath());
                // Dapat tipe file dari ekstensi
                String fileType = getFileExtension(file);
                // Berhasil diunggah, tampilkan notifi
                JOptionPane.showMessageDialog(null, "Upload berhasil!\nFile: " + nama + "\nTipe: " + fileType, 
                                              "Sukses", JOptionPane.INFORMATION_MESSAGE);
                // Simpan byte array file dan tipe file ke variabel
                iconBytes = fileBytes; 
                fileTypeVar = fileType;
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Gagal mengunggah file!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Upload dibatalkan!", "Peringatan", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        if (id == 0) {
            JOptionPane.showMessageDialog(this, "ID siswa belum terisi, login kembali!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String selectedPertemuan = (String) comboPilih.getSelectedItem();
        if (selectedPertemuan == null || iconBytes == null) {
            JOptionPane.showMessageDialog(this, "Pilih pertemuan dan unggah bukti!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // dapat status
        String status = "diserahkan";
        // Query untuk mendapat id_pertemuan
        String sq = "SELECT id_absensi FROM absensi WHERE nama_pertemuan = ?";
        try (PreparedStatement pss = conn.prepareStatement(sq)) {
            if (selectedPertemuan == null || selectedPertemuan.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nama pertemuan tidak valid", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            pss.setString(1, selectedPertemuan);
            ResultSet rs = pss.executeQuery();
            if (rs.next()) {
                id_pertemuan = rs.getInt("id_absensi"); 
            } else {
                JOptionPane.showMessageDialog(this, "Pertemuan tidak ditemukan!", "Error", JOptionPane.ERROR_MESSAGE);
                return;  
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saat memeriksa pertemuan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        // Query untuk menyimpan absensi
        String sql = "INSERT INTO absensi_siswa (id_siswa, id_pertemuan, bukti, tipe_file, status_absensi) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id); 
            ps.setInt(2, id_pertemuan);  
            ps.setBytes(3, iconBytes);    
            ps.setString(4, fileTypeVar); 
            ps.setString(5, status);      
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Absensi berhasil dikirim!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Gagal mengirim absensi.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal mengirim absensi: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Login log = new Login(); 
        log.setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomepageSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomepageSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomepageSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomepageSiswa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomepageSiswa(0,"").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel berandaPanel;
    private javax.swing.JButton btnJoin;
    private javax.swing.JComboBox<String> comboPilih;
    private javax.swing.JPanel homePanel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel labelAbsensi;
    private javax.swing.JTextField tfKode;
    // End of variables declaration//GEN-END:variables
}
