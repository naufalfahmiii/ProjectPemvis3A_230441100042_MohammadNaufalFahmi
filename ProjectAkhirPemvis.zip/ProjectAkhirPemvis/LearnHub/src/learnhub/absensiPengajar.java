/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package learnhub;

import com.mysql.cj.jdbc.Blob;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Date;
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author THINKPAD
 */
public class absensiPengajar extends javax.swing.JFrame {
    private Connection conn;
    private int idPertemuan;
    private byte[] iconBytes;

    /**
     * Creates new form absensiPengajar
     */
    public absensiPengajar() {
        initComponents();
        conn = koneksi.getKoneksi();
        loadComboBoxData();
//         loadDataAbsensi();
    }
       private String getFileExtension(File file) {
        String name = file.getName();
        int lastIndex = name.lastIndexOf('.');
        if (lastIndex > 0 && lastIndex < name.length() - 1) {
            return name.substring(lastIndex + 1).toLowerCase();
        }
        return "unknown"; // Jika tidak ada ekstensi
    }
    private void loadComboBoxData() {
    try {
        // Query untuk mengambil semua pertemuan dari database
        String sql = "SELECT id_absensi, nama_pertemuan FROM absensi";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
        // Mengisi combo box dengan pertemuan yang ada
        comboTemu.removeAllItems();  // Kosongkan combo box terlebih dahulu
        comboTemu.addItem("Pilih Pertemuan");  // Menambahkan pilihan default
        while (rs.next()) {
            // Menambahkan item ke combo box dengan format "ID - Nama Pertemuan"
            int idPertemuan = rs.getInt("id_absensi");
            String namaPertemuan = rs.getString("nama_pertemuan");
            comboTemu.addItem(idPertemuan + " - " + namaPertemuan);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error Load Combo Pertemuan: " + e.getMessage());
    }
}
    private void loadDataAbsensiById(int idPertemuan) {
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("No");
    model.addColumn("Nama Siswa");
    model.addColumn("Bukti");
    model.addColumn("Status");
    model.addColumn("ID");
    model.addColumn("Tipe File");  // Tambahkan kolom Tipe File

    try {
        // Query untuk mengambil data absensi berdasarkan ID pertemuan
        String sql = "SELECT a.id, u.username, a.bukti, a.status_absensi, a.tipe_file " +
                     "FROM absensi_siswa a " +
                     "JOIN users u ON a.id_siswa = u.id " +
                     "WHERE a.id_pertemuan = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, idPertemuan);  // Set ID pertemuan yang dipilih
        ResultSet rs = ps.executeQuery();

        int nomor = 1;
        while (rs.next()) {
            // Ambil nama file dari path bukti
            String fileName = new File(rs.getString("bukti")).getName();
            String fileType = rs.getString("tipe_file");  // Ambil tipe file dari database

            model.addRow(new Object[]{
                nomor++,
                rs.getString("username"),
                fileName,
                rs.getString("status_absensi"),
                rs.getInt("id"),  // Menambahkan ID absensi
                fileType  // Menambahkan tipe file
            });
        }

        // Set model ke tabel
        tabelAbsen.setModel(model);

        // Menyembunyikan kolom ID dan Tipe File
        tabelAbsen.getColumnModel().getColumn(4).setMinWidth(0);
        tabelAbsen.getColumnModel().getColumn(4).setMaxWidth(0);
        tabelAbsen.getColumnModel().getColumn(4).setWidth(0);

        tabelAbsen.getColumnModel().getColumn(5).setMinWidth(0);  // Menyembunyikan kolom Tipe File
        tabelAbsen.getColumnModel().getColumn(5).setMaxWidth(0);
        tabelAbsen.getColumnModel().getColumn(5).setWidth(0);

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error Load Data Absensi: " + e.getMessage());
    }
}

    private void konfirmasiAbsensi() {
    // Cek apakah ada baris yang dipilih di tabel
        int selectedRow = tabelAbsen.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data absensi terlebih dahulu!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // Mendapatkan ID absensi dari kolom tersembunyi
        int idAbsensi = (int) tabelAbsen.getValueAt(selectedRow, 4);
        // Mendapatkan status dari radio button yang dipilih
        String status = "";
        if (rbTerima.isSelected()) {
            status = "hadir";
        } else if (rbTolak.isSelected()) {
            status = "idak hadir";
        } else {
            JOptionPane.showMessageDialog(this, "Pilih status konfirmasi terlebih dahulu!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            // Update status absensi di database
            String sql = "UPDATE absensi_siswa SET status_absensi = ? WHERE id = ?";
            PreparedStatement ps = koneksi.getKoneksi().prepareStatement(sql);
            ps.setString(1, status);
            ps.setInt(2, idAbsensi);
            int updatedRows = ps.executeUpdate();
            if (updatedRows > 0) {
                JOptionPane.showMessageDialog(this, "Status absensi berhasil diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadDataAbsensiById(idPertemuan); // Memuat ulang data di tabel
            } else {
                JOptionPane.showMessageDialog(this, "Gagal memperbarui status absensi.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void clearForm() {
    // Bersihkan semua TextField
        tfTemu.setText("");
        dateChooser.setDate(null); // JDateChooser di-reset ke null
        // Bersihkan ComboBox jika diperlukan
        comboTemu.setSelectedIndex(0);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupKonfirm = new javax.swing.ButtonGroup();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        comboTemu = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelAbsen = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        rbTerima = new javax.swing.JRadioButton();
        rbTolak = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        tfTemu = new javax.swing.JTextField();
        dateChooser = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        btnBuat = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(101, 146, 135));

        jTabbedPane1.setBackground(new java.awt.Color(177, 194, 158));

        jPanel1.setBackground(new java.awt.Color(177, 194, 158));
        jPanel1.setLayout(null);

        jLabel4.setText("Pilih Absensi");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(150, 70, 70, 16);

        comboTemu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboTemuActionPerformed(evt);
            }
        });
        jPanel1.add(comboTemu);
        comboTemu.setBounds(320, 70, 190, 22);

        tabelAbsen.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "id absensi", "nama siswa", "bukti", "status absensi"
            }
        ));
        tabelAbsen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelAbsenMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabelAbsen);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(150, 110, 370, 220);

        jButton1.setBackground(new java.awt.Color(101, 146, 135));
        jButton1.setText("Konfirmasi");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(430, 350, 90, 23);

        grupKonfirm.add(rbTerima);
        rbTerima.setText("Terima");
        jPanel1.add(rbTerima);
        rbTerima.setBounds(150, 350, 80, 21);

        grupKonfirm.add(rbTolak);
        rbTolak.setText("Tidak");
        jPanel1.add(rbTolak);
        rbTolak.setBounds(310, 350, 70, 21);

        jTabbedPane1.addTab("Cek Absensi", jPanel1);

        jPanel2.setBackground(new java.awt.Color(177, 194, 158));

        jLabel5.setText("Pertemuan Ke");

        dateChooser.setDateFormatString("yyyy-MM-dd");

        jLabel6.setText("Tanggal Pertemuan");

        btnBuat.setBackground(new java.awt.Color(101, 146, 135));
        btnBuat.setText("Buat");
        btnBuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(207, 207, 207)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(dateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnBuat, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addGap(47, 47, 47)
                        .addComponent(tfTemu, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(238, 238, 238))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tfTemu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addComponent(btnBuat)
                .addContainerGap(189, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Buat Absensi", jPanel2);

        jLabel2.setText("Absensi");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(340, 340, 340)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 734, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuatActionPerformed
        // TODO add your handling code here:
        // Validasi input
        String namaPertemuan = tfTemu.getText().trim();
        java.util.Date tanggal = dateChooser.getDate();
        if (namaPertemuan.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama pertemuan tidak boleh kosong.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (tanggal == null) {
            JOptionPane.showMessageDialog(this, "Tanggal pertemuan tidak boleh kosong.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            // Koneksi ke database
            String query = "INSERT INTO absensi (nama_pertemuan, tanggal_pertemuan) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, namaPertemuan);
            stmt.setDate(2, new java.sql.Date(tanggal.getTime()));
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Absensi berhasil dibuat.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadComboBoxData(); // Load data ke ComboBox
                clearForm(); // Bersihkan form
            } else {
                JOptionPane.showMessageDialog(this, "Gagal membuat absensi.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan pada database.\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnBuatActionPerformed

    private void tabelAbsenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelAbsenMouseClicked
        // TODO add your handling code here:
       int row = tabelAbsen.getSelectedRow();
    if (row != -1) {
        // Menyiapkan ID Absensi dari kolom ke-4 (kolom ID Absensi)
        int absensiId = Integer.parseInt(tabelAbsen.getValueAt(row, 4).toString());  // ID Absensi

        // Mengambil bukti berdasarkan ID absensi dan membuka file bukti
        String sql = "SELECT bukti, tipe_file FROM absensi_siswa WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, absensiId);  // Set ID Absensi yang dipilih
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // Mendapatkan BLOB file bukti dan tipe file
                    Blob blobBukti = (Blob) rs.getBlob("bukti");
                    String fileType = rs.getString("tipe_file");
                    
                    if (blobBukti != null && fileType != null && !fileType.isEmpty()) {
                        // Menyimpan BLOB ke file sementara
                        InputStream inputStream = blobBukti.getBinaryStream();
                        File tempFile = File.createTempFile("bukti_", "." + fileType);
                        
                        try (FileOutputStream outputStream = new FileOutputStream(tempFile)) {
                            byte[] buffer = new byte[1024];
                            int bytesRead;
                            while ((bytesRead = inputStream.read(buffer)) != -1) {
                                outputStream.write(buffer, 0, bytesRead);
                            }
                        }
                        
                        if (tempFile.exists() && Desktop.isDesktopSupported()) {
                            // Membuka file bukti dengan aplikasi default
                            Desktop.getDesktop().open(tempFile);
                        } else {
                            JOptionPane.showMessageDialog(this, "Gagal membuka file bukti.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Bukti tidak tersedia untuk absensi ini.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Absensi dengan ID tersebut tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException | IOException e) {
                JOptionPane.showMessageDialog(this, "Gagal mengambil bukti: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error dalam mengambil data absensi: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_tabelAbsenMouseClicked

    private void comboTemuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboTemuActionPerformed
        // TODO add your handling code here:
         // Ambil item yang dipilih dari combo box
    String selectedItem = (String) comboTemu.getSelectedItem();

    // Validasi jika belum memilih pertemuan
    if (selectedItem == null || selectedItem.equals("Pilih Pertemuan")) {
        return; // Tidak melanjutkan jika belum memilih pertemuan
    }
    
    // Ekstrak ID pertemuan dari format "ID - Nama Pertemuan"
    int idPertemuan = Integer.parseInt(selectedItem.split(" - ")[0].trim());
    
    // Panggil fungsi untuk memuat data absensi berdasarkan ID pertemuan yang dipilih
    loadDataAbsensiById(idPertemuan);
    
    // Menutup dropdown ComboBox setelah pemilihan
    comboTemu.hidePopup();
    }//GEN-LAST:event_comboTemuActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        konfirmasiAbsensi();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(absensiPengajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(absensiPengajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(absensiPengajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(absensiPengajar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new absensiPengajar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuat;
    private javax.swing.JComboBox<String> comboTemu;
    private com.toedter.calendar.JDateChooser dateChooser;
    private javax.swing.ButtonGroup grupKonfirm;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JRadioButton rbTerima;
    private javax.swing.JRadioButton rbTolak;
    private javax.swing.JTable tabelAbsen;
    private javax.swing.JTextField tfTemu;
    // End of variables declaration//GEN-END:variables
}
